//
//  Car.swift
//  app-cars
//
//  Created by Austin Ramsdale on 9/13/20.
//

import Foundation

struct Car {
    var brandName = ""
    var modelName = ""
    var modelYear = ""
    var msrp = ""
    var fuelEconomy = ""
    var engine = ""
    var horsepower = ""
    var transmission = ""
    var image = ""
    var logo = ""
}
